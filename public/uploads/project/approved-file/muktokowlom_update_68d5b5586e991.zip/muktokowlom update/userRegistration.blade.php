@extends('layouts.master')
@section('content')

<div class="container mt-4 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8"> <!-- Adjust width here -->
            <div class="card shadow-lg rounded-3">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-3">User Registration</h4>
                    <p class="text-muted text-center mb-4">
                        Please fill in the form below to register a new user.
                    </p>

                    <!-- Registration form -->
                    <form>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label fw-semibold">Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label fw-semibold">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label fw-semibold">Phone</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label fw-semibold">Address (Optional)</label>
                            <textarea class="form-control" id="address" name="address" rows="3"></textarea>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-sm btn-primary">
                                Register
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Table placeholder below the form -->
            <div class="mt-4">
                <!-- //table -->
            </div>
        </div>
    </div>
</div>

@endsection
