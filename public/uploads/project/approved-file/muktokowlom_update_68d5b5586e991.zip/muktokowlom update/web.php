<?php

use App\Http\Controllers\Admin\TeamMemberController;
use App\Http\Controllers\SocialiteController;
use App\Http\Controllers\WebsiteController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\StoriesController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\Admin\SubscriptionController;

Route::controller(WebsiteController::class)->group(function () {
    Route::get('/', 'index')->name('welcome');
    Route::get('/about', 'about')->name('about');
    Route::get('/faqs', 'faq')->name('faqs');
    Route::get('/submission-guideline', 'submission_guide')->name('submission-guideline');
    Route::get('/privacy-policy', 'privacy_policy')->name('privacy-policy');
    Route::get('/user/login', 'login')->name('user.login');
    Route::get('/user/registration', 'registration')->name('user.registration');
    Route::get('/writer/registration', 'writerRegistration')->name('writer.registration');
    Route::get('/user/email-verification', 'emailVerification')->name('user.email-verification');
    Route::get('/user/re-send-verification', 'reSendVerification')->name('user.re-send-verification');
    Route::get('/user/contact', 'contact')->name('contact-us');
    Route::post('/user/contact/meassage', 'meassageSend')->name('user.contact.meassage');
    Route::get('/story/details/{id}/{title}', 'storyDetails')->name('story.details');
    Route::get('/writer/profile/{id}/{name}', 'writerProfile')->name('writer.profile');
    Route::get('/categorywise/{id}/{userId}/stories', 'getCategoryStories')->name('category.stories');
    Route::get('/category/{id}/stories', 'categoryStories')->name('category-wise-stories');
    Route::get('/tag/{tag}/stories', 'tagStories')->name('tag-wise-story');
    Route::get('/stories/search', 'search')->name('stories.search');
    Route::get('purchase-plans', 'purchasePlans')->name('purchase-plans');
    Route::get('terms-and-conditions', 'termsConditions')->name('terms-conditions');
    Route::get('careers', 'careerDetails')->name('career');

    // magazine
    Route::get('magazine', 'magazineInfo')->name('magazine');
    Route::get('user-registration-info','userRegisterInfo')->name('user-registration-info');
    Route::get('user-registration', 'userRegistrations')->name('user-registration');
    Route::get('design-submission', 'designSubmission')->name('design-submission');

});

// writer registration
Route::post('/writer/register', 'Auth\RegisterController@writerRegister')->name('writer.register');
Route::post('/user/register', 'Auth\RegisterController@userRegister')->name('user.register');
Route::post('/user-login', 'Auth\LoginController@customLogin')->name('customLogin');
Route::post('/user/email-verification-check', 'Auth\RegisterController@emailVerification')->name('user.email-verification.check');
Route::post('/user/resend-verification-store', 'Auth\RegisterController@resendVerificationStore')->name('user.resend-verification.store');
// story view
Route::get('stories', function () {
    return view('frontend.stories.index');
});

Route::post('/user/story/viewcount', 'StoriesController@incrementViewCount')->name('user.story.viewcount');

Route::get('view/stories', function () {
    return view('frontend.stories.view');
});

// refund and cancellation
Route::get('refund-policy', function() {
    return view('frontend.refund.refund');
});

Route::controller(SocialiteController::class)->group(function() {
    Route::get('auth/redirection/{provider}', 'authProviderRedirect')->name('auth.redirection');

    Route::get('auth/{provider}/callback', 'socialAuthentication')->name('auth.callback');
});

// Localization
Route::get('/lang', [LanguageController::class, 'switchLang'])->name('lang.switch');

// Route::redirect('/', '/login');
//Route::get('/home', function () {
//    if (session('status')) {
//        return redirect()->route('admin.home')->with('status', session('status'));
//    }
//    return redirect()->route('admin.home');
//});

Auth::routes(['register' => true]);

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth', 'admin']], function () {
    Route::get('/', 'HomeController@index')->name('home');

    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');
    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');
    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');
    Route::get('/users/banned-status-change/{id}', 'UsersController@bannedStatusChange')->name('users.bannedStatusChange');
    Route::get('/user/attach-file/{id}', 'UsersController@attachFileView')->name('user.attach-file');
    Route::get('/writer/application-list', 'UsersController@writerApplicationList')->name('users.writer.application.list');
    Route::get('/users/writer-status-change/{userId}/{value}', 'UsersController@writerStatusChange')->name('users.writerStatusChange');
    // Categories
    Route::delete('categories/destroy', 'CategoryController@massDestroy')->name('categories.massDestroy');
    Route::resource('categories', 'CategoryController');

    // About
    Route::get('about', 'SiteController@about')->name('about');
    Route::post('about/update', 'SiteController@aboutStore')->name('about.update');

    // Submission
    Route::get('submissions', 'SiteController@submission')->name('submissions');
    Route::post('submissions/store', 'SiteController@submissionstore')->name('submissions.store');

    // Privacy & policy
    Route::get('privacy-policy', 'SiteController@privacyPolicy')->name('privacy.policy');
    Route::post('privacy-policy/store', 'SiteController@privacyPolicyStore')->name('privacy.store');

    // Terms & Conditions
    Route::get('terms-and-conditions', 'SiteController@termsConditions')->name('terms.conditions');
    Route::post('terms-and-conditions/store', 'SiteController@termsConditionsStore')->name('terms.store');

    // FAQ
    Route::get('faqs', 'SiteController@faqs')->name('faqs');
    Route::post('faqs/store', 'SiteController@faqsStore')->name('faqs.store');

    // subscriptions
    Route::resource('subscriptions', SubscriptionController::class);

    // team members
    Route::resource('team-members', TeamMemberController::class);

    // Stories
    Route::delete('categories/destroy', 'CategoryController@massDestroy')->name('categories.massDestroy');
    Route::resource('stories', 'StoriesController');
    Route::post('/stories/updateStatus', 'StoriesController@updateStatus')->name('stories.updateStatus');
    Route::get('/view/english-story/{id}', 'StoriesController@englishPDFView')->name('view.english.story');
    Route::get('/view/bangla-story/{id}', 'StoriesController@banglaPDFView')->name('view.bangla.story');
    Route::get('/Story/payable-status-change/{id}/{value}', 'StoriesController@payableStatusChange')->name('stories.payablestatus');
    Route::get('/application/story', 'StoriesController@applicationStory')->name('application.story');
    Route::put('/stories/{story}/update-image', 'StoriesController@updateImage')->name('stories.updateImage');

    //Writer Payment List
    Route::get('writer-list', 'HomeController@writerList')->name('writer.list');
    Route::get('writer/{id}/payment-list', 'HomeController@writerPaymentList')->name('writer.payment-list');
    Route::get('writer-payment-history', 'HomeController@writerPaymentHistory')->name('writer.payment.history');
    Route::get('writer/{id}/payment-history-details', 'HomeController@writerPaymentHistoryDetails')->name('writer.payment.history.view');

    // software settings
    Route::get('settings', 'SettingController@setting')->name('settings');
    Route::post('settings/store', 'SettingController@store')->name('settings.store');

    // views rating
    Route::get('views-rating', 'SettingController@viewsRating')->name('views-rating');
    Route::post('views-rating/store', 'SettingController@viewsRatingStore')->name('views-rating.store');

    //
    Route::get('/send-email-form','HomeController@sendEmail')->name('send-email-form');
    Route::post('/send-emails', 'HomeController@mailSend')->name('send.emails');
});


Route::group(['prefix' => 'user', 'as' => 'user.','middleware' => ['auth','is_unbanned']], function () {
    Route::get('dashboard', 'HomeController@dashboard')->name('dashboard');
    Route::post('story/store', 'StoriesController@store')->name('story.store');
    Route::get('story/create', 'StoriesController@create')->name('story.create');
    Route::get('story/history', 'StoriesController@history')->name('story.history');
    Route::get('earn/history', 'StoriesController@earnHistory')->name('earn.history');
    Route::get('story/edit/{id}', 'StoriesController@edit')->name('story.edit');
    Route::get('story/show/{id}', 'StoriesController@show')->name('story.show');
    Route::get('view/english-story-file/{id}', 'StoriesController@englishStoryFile')->name('view.english.story');
    Route::get('view/bangla-story-file/{id}', 'StoriesController@banglaStoryFile')->name('view.bangla.story');
   // Route::post('/story/viewcount', 'StoriesController@incrementViewCount')->name('story.viewcount');
    Route::put('story/update/{id}', 'StoriesController@update')->name('story.update');
    Route::delete('story/delete/{id}', 'StoriesController@destroy')->name('story.destroy');
    Route::get('profile', 'HomeController@profile')->name('profile');
    Route::get('account/delete', 'HomeController@accountDelete')->name('account.delete');
    Route::put('personal-information/update/{id}', 'HomeController@personalInformationUpdate')->name('profile.information.update');
    Route::put('password/update/{id}', 'HomeController@passwordUpdate')->name('profile.password.update');
    Route::get('bank/info', 'HomeController@bankInfo')->name('bank.info');
    Route::put('bank-information/update/{id}', 'HomeController@bankInformationUpdate')->name('bank.information.update');

    // comment
    Route::post('/comments/store', [CommentController::class, 'store'])->name('comments.store');
    Route::post('/comments/reply', [CommentController::class, 'replyStore'])->name('comments.reply');

});


  // Subscription

Route::group(['middleware' => ['auth']], function () {
    Route::post('/payment', [PaymentController::class, 'payment'])->name('payment');
    Route::post('/writer-payment', [PaymentController::class, 'writerPayment'])->name('admin.writer.payment');
    Route::post('/success', [PaymentController::class,'success'])->name('success');
    Route::post('/fail', [PaymentController::class,'fail'])->name('fail');
    Route::post('/cancel', [PaymentController::class,'cancel'])->name('cancel');

});

Route::fallback([WebsiteController::class, 'notFound'])->name('fallback.notfound');



//Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['auth']], function () {
//    // Change password
//    if (file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {
//        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
//        Route::post('password', 'ChangePasswordController@update')->name('password.update');
//        Route::post('profile', 'ChangePasswordController@updateProfile')->name('password.updateProfile');
//        Route::post('profile/destroy', 'ChangePasswordController@destroy')->name('password.destroyProfile');
//    }
//});

