@extends('layouts.master')

@section('content')
<div class="container mt-5">
    <div class="row">
        <!-- Left Div -->
        <div class="col-md-6">
            <h3 class="mb-4">Submit Your Design</h3>
            <form action="" method="POST" enctype="multipart/form-data">
                @csrf

                <!-- Name -->
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" required>
                </div>

                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" required>
                </div>

                <!-- File -->
                <div class="mb-3">
                    <label for="file" class="form-label">Upload File:</label>
                    <input type="file" name="file" id="file" class="form-control" required>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>

        <!-- Right Div -->
        <div class="col-md-6 d-flex align-items-center justify-content-center">
            <img src="{{ asset('assets/img/demo-magazine-cover.jpg') }}" alt="Preview" class="img-fluid rounded shadow">
        </div>
    </div>
</div>
@endsection
