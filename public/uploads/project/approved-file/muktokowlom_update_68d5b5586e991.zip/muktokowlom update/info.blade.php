@extends('layouts.master')
@section('content')
    {{-- bangla font --}}
    <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">

    <div class="container my-5">
        <div class="row align-items-center" style="margin-left: auto; margin-right: auto;">

            <!-- Left Column: Magazine Cover -->
            <div class="col-md-6 text-center mb-4 mb-md-0">
                <div class="position-relative d-inline-block">
                    <img src="{{ asset('assets/img/demo-magazine-cover.jpg') }}" alt="Magazine Cover" class="img-fluid border" style="height: 20rem; width: auto;">
                    <span class="text-danger font-weight-bold position-absolute" style="top:-25px; right:0;">
                        একটু পড়ে দেখুন ↓
                    </span>
                </div>
            </div>

            <!-- Right Column: Price & Details -->
            <div class="col-md-6">
                <!-- Price -->
                <h5 class="text-dark">Tk. 60</h5>

                <!-- Stock Info -->
                <p class="mb-1">
                    <span class="text-success font-weight-bold">
                        <i class="fa fa-check-circle"></i> In Stock
                    </span>
                    <small class="text-danger">(only 3 copies left)</small>
                </p>
                <small class="text-muted">* স্টক আউট হওয়ার আগেই অর্ডার করুন</small>

                <!-- Buttons -->
                <div class="mt-3">
                    <a href="#" class="btn btn-outline-primary btn-sm mr-2">একটু পড়ে দেখুন</a>
                    <a href="#" class="btn btn-primary btn-sm">
                        <i class="fa fa-shopping-cart"></i> Buy Now
                    </a>
                </div>

                <hr>

                <!-- Share -->
                <div class="mt-2">
                    <a href="#" class="text-muted"><i class="fa fa-share-alt"></i> বন্ধুদের সাথে শেয়ার করুন</a>
                </div>

                <!-- Title -->
                <h3 class="mt-2" style="font-family: 'SolaimanLipi', sans-serif;">
                    মুক্তকলম ম্যাগাজিন এর প্রথম সংখ্যা !
                </h3>
            </div>

        </div>
    </div>

    <!-- second part -->
    <div class="mb-5" style="background-color: #E1DCD2;">
        <div class="container">
            <div class="row">
                <!-- Heading and Info -->
                <div class="col-md-12 mt-4">
                    <h5 class="font-weight-bold mb-3" style="font-family: 'SolaimanLipi', sans-serif; text-align: center; font-size: 2.3rem;">
                        মুক্তকলম ম্যাগাজিন এর প্রথম সংখ্যার কভার ডিজাইন প্রতিযোগিতা ২০২৫
                    </h5>
                    <ul style="font-family: 'SolaimanLipi', sans-serif;">
                        <li>সবচেয়ে ডিজাইনারদের ১লা সেপ্টেম্বর এর মধ্যে ফ্রি রেজিস্ট্রেশনের সুযোগ থাকবে</li>
                        <li>১লা সেপ্টেম্বর এর পর ডিজাইনারদের ১০০ টাকা ফি দিয়ে রেজিস্ট্রেশন করতে হবে</li>
                        <li>১৫ অক্টোবর রাত ১১:৫৯ মিনিট ডিজাইন জমা দেওয়ার শেষ সময়</li>
                        <li>২০ অক্টোবর বিজয়ীর নাম ঘোষণা করা হবে</li>
                    </ul>

                    <p class="mt-3" style="font-family: 'SolaimanLipi', sans-serif; margin-left: 25px; font-size: 1.3rem;">
                        ১ম পুরস্কার ১৫,০০০ টাকা <br>
                        ২য় পুরস্কার ৭,০০০ টাকা <br>
                        ৩য় পুরস্কার ৩,০০০ টাকা
                    </p>
                </div>
            </div>

            <style>
                .w-60 {
                    width: 60%;
                }

                .custom-btn {
                    border-radius: 20px;
                }
            </style>

            <!-- Buttons (Left) and Image (Right) -->
            <div class="row align-items-center">
                <div class="col-md-5 d-flex justify-content-center">
                    <div class="d-flex flex-column gap-2 w-100 align-items-center">
                        <a href="{{ route('user-registration-info') }}" class="btn btn-danger m-2 w-60 custom-btn">Register Now</a>
                        <a href="#" class="btn btn-secondary m-2 w-60 custom-btn">Design Brief</a>
                        <a href="{{ route('design-submission') }}" class="btn btn-primary m-2 w-60 custom-btn">Submit Design</a>
                    </div>
                </div>

                <div class="col-md-7 text-center mt-3 mt-md-0">
                    <img src="{{ asset('assets/img/demo-magazine-cover.jpg') }}" alt="Design Competition" class="img-fluid rounded shadow"
                        style="height: 20rem; width: auto;">
                </div>
            </div>
        </div>
    </div>
@endsection
