@extends('layouts.master')
@section('content')
<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
<style>
    body {
        font-family: 'SolaimanLipi', Arial, sans-serif;
    }

    .section-title {
        font-size: 1.5rem;
        font-weight: bold;
        margin-bottom: 2rem;
    }

    .card-custom {
        border: none;
        text-align: center;
        padding: 20px;
    }

    .card-custom h3 {
        font-weight: bold;
        font-size: 1.5rem;
    }

    .btn-custom {
        border-radius: 25px;
        padding: 10px 20px;
        font-weight: bold;
    }

    .divider {
        border-left: 2px solid #000;
        height: 100%;
    }

    .border-right-custom {
        border-right: 4px solid black; 
    }
</style>

<div class="container mt-5 mb-3">
    <h2 class="section-title" style="text-align: center; font-size: 1.9rem;">
        মুক্তকলম ম্যাগাজিন এর প্রথম সংখ্যার কভার ডিজাইন প্রতিযোগিতা ২০২৫
    </h2>

  <div class="row align-items-center">
    <!-- Left Column -->
    <div class="col-md-6 text-center border-right-custom">
      <h3><b>প্রি রেজিস্ট্রেশন</b></h3>
        <p>- ফ্রি রেজিস্ট্রেশন</p>
        <p>- ১লা সেপ্টেম্বর পর্যন্ত</p>
      <a href="{{ route('user-registration') }}" class="btn btn-sm btn-dark rounded-pill px-4">প্রি রেজিস্ট্রেশন</a>
    </div>

    <!-- Right Column -->
    <div class="col-md-6 text-center">
      <h3><b>রেজিস্ট্রেশন</b></h3>
      <p>০২ সেপ্টেম্বর - ১৪ অক্টোবর</p>
      <p>১০০ টাকা রেজিস্ট্রেশন ফি</p>
      <a href="{{ route('user-registration') }}" class="btn btn-sm btn-dark rounded-pill px-4">রেজিস্ট্রেশন</a>
    </div>

  </div>
</div>
@endsection