<?php

return [
    'site_title' => 'Chobi Dokan',
];
